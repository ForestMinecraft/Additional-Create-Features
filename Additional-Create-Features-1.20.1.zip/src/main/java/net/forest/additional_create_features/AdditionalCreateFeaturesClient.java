package net.forest.additional_create_features;

import net.fabricmc.api.ClientModInitializer;

public class AdditionalCreateFeaturesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
